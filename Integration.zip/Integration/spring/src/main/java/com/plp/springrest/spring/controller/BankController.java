package com.plp.springrest.spring.controller;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
/*import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;*/
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.plp.springrest.spring.bean.Bank;
import com.plp.springrest.spring.bean.Transaction;
import com.plp.springrest.spring.exception.BankException;
import com.plp.springrest.spring.service.BankService;

@CrossOrigin(origins="http://localhost:4200")
@RestController
public class BankController 
{
@Autowired
BankService bankService;

@RequestMapping(value="/user/add" ,method=RequestMethod.POST)
public Bank createBankAccount(@RequestBody Bank bank) throws BankException
{
	
	return bankService.createBankAccount(bank);
	 //return new ResponseEntity<String>("Your Account Id is "+bank.getAccountId()+"", HttpStatus.OK);
}

@RequestMapping("/user/show/{accNum}")
public double balanceEnquiry(@PathVariable int accNum) throws BankException
{
	return bankService.balanceEnquiry(accNum);
}

@RequestMapping(value="/user/deposit/{accNum}/{deposit}",method=RequestMethod.PUT)
public double moneyDeposit(@PathVariable Integer accNum,@PathVariable Integer deposit) throws BankException{
	
		return bankService.moneyDeposit(accNum, deposit);
}
@RequestMapping(value="/user/withdraw/{accNum}/{withdraw}",method=RequestMethod.PUT)
public double moneyWithdrawl(@PathVariable Integer accNum,@PathVariable Integer withdraw) throws BankException
{
		return bankService.moneyWithdrawl(accNum, withdraw);
		
}
@RequestMapping(value="/user/transfer/{sourceAcc}/{destinationAcc}/{amount}",method=RequestMethod.GET)
public int moneyTransfer(@PathVariable int sourceAcc,@PathVariable int destinationAcc,@PathVariable double amount) throws BankException
{
	try {
		bankService.moneyTransfer(sourceAcc, destinationAcc, amount);
		return 1;
	}
	catch(Exception ex)
	{
		return 0;
	}	
}
@GetMapping("/statement/{accnum}")
public List<Transaction> printStatement(@PathVariable long accnum){
	return bankService.Statement(accnum);
}

}
