import { Transacation } from './transacation';

describe('Transacation', () => {
  it('should create an instance', () => {
    expect(new Transacation()).toBeTruthy();
  });
});
