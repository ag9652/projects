import { Component, OnInit } from '@angular/core';
import { Customer } from '../customer';
import { Transaction } from '../transaction';
import { CustomerServiceService } from '../customer-service.service';
@Component({
  selector: 'app-transactions',
  templateUrl: './transactions.component.html',
  styleUrls: ['./transactions.component.css']
})
export class TransactionsComponent implements OnInit {
  
  transactionId:number;

  constructor(private customerService : CustomerServiceService) { }

  ngOnInit() {
  }
  printTransactions(accnum): number
  {
  this.customerService.printTransactions(accnum).subscribe(data=>{
  this.transactionId=data;
  console.log(this.transactionId);  
})
return this.transactionId;
  }
}
