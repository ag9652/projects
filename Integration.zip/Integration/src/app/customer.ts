export class Customer 
{
 public accountId: number;
 public username: string;
 public balance: number;
 public phoneNumber: string;
 public password:String;
 public accNumber:number;
 public amount:number;
 public transactionType:String;
}
