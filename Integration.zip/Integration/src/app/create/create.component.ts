import { Component, OnInit } from '@angular/core';
import { Customer } from '../customer';
import { CustomerServiceService } from '../customer-service.service';

@Component({
  selector: 'app-create',
  templateUrl: './create.component.html',
  styleUrls: ['./create.component.css']
})
export class CreateComponent implements OnInit {
  user: Customer;
constructor(private customerService:CustomerServiceService) 
{  
  this.user =new Customer();
}
   
  ngOnInit() {
  }

  createBankAccount(balance,psw,phoneNumber,username):void {
    this.user.balance=balance;
    this.user.password=psw;
    this.user.phoneNumber=phoneNumber;
    this.user.username=username;
    this.customerService.createBankAccount(this.user).subscribe(data => {
    alert("Account created successfully.");
    });
}
}

