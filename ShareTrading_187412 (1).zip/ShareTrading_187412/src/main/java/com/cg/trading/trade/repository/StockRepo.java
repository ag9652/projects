package com.cg.trading.trade.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cg.trading.trade.entity.Stock;

@Repository
public interface StockRepo extends JpaRepository<Stock, Integer> {

	@Query("from Stock where id= :id")
	Optional<Stock> findById(@Param("id") int id);

}
