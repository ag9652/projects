package com.cg.trading.trade.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.trading.trade.entity.Stock;
import com.cg.trading.trade.exception.StockException;
import com.cg.trading.trade.repository.StockRepo;

@Service
public class StockServiceImpl implements StockService {

	@Autowired
	StockRepo stockRepo;

	@Override
	public List<Stock> createStock(Stock bean) throws StockException {
		try {
			bean.setAmount(bean.getPrice() * bean.getQuantity());
			if (bean.getQuantity() > 100) {
				bean.setBrokerage(bean.getAmount() * 0.3 * 0.01);
			} else {
				bean.setBrokerage(bean.getAmount() * 0.5 * 0.01);
			}
			stockRepo.save(bean);
			stockRepo.flush();
			return stockRepo.findAll();
		} catch (Exception e) {
			throw new StockException("Cannot be added");
		}
	}

	@Override
	public List<Stock> updateStock(int id, Stock bean) throws StockException {
		try {
			Optional<Stock> optional = stockRepo.findById(id);
			if (optional.isPresent()) {
				Stock stock = optional.get();
				stock.setName(bean.getName()); // To update Name
				stock.setPrice(bean.getPrice()); // To update Price
				stock.setQuantity(bean.getQuantity()); // To update Quantity
				stock.setAmount(stock.getPrice() * stock.getQuantity()); // To update Amount based on updated Price &
																			// Quantity
				stockRepo.save(stock);
				return stockRepo.findAll();
			} else {
				throw new StockException();
			}
		} catch (Exception e) {
			throw new StockException("Cannot be updated");
		}
	}

	@Override
	public void deleteStock(int id) throws StockException {
		try {
			stockRepo.deleteById(id);
		} catch (Exception e) {
			throw new StockException("Id does not exist");
		}

	}

	@Override
	public List<Stock> viewAllStock() throws StockException {
		try {
			return stockRepo.findAll();
		} catch (Exception e) {
			throw new StockException("There must be some problem...Check again");
		}
	}

	@Override
	public Stock findSingleStock(int id) throws StockException {
		try {
			return stockRepo.findById(id).get();
		} catch (Exception e) {
			throw new StockException("Id does not exist");
		}
	}

}
