package com.cg.trading.trade.service;

import java.util.List;

import com.cg.trading.trade.entity.Stock;
import com.cg.trading.trade.exception.StockException;

public interface StockService {

	List<Stock> createStock(Stock bean) throws StockException;

	List<Stock> updateStock(int id, Stock bean) throws StockException;

	void deleteStock(int id) throws StockException;

	List<Stock> viewAllStock() throws StockException;

	Stock findSingleStock(int id) throws StockException;

}
