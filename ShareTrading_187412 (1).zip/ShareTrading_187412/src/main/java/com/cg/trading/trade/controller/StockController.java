package com.cg.trading.trade.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.trading.trade.entity.Stock;
import com.cg.trading.trade.exception.StockException;
import com.cg.trading.trade.service.StockService;

@RestController
public class StockController {

	@Autowired
	StockService stockService;

	@RequestMapping(value = "/createStock", method = RequestMethod.POST)
	public List<Stock> createStock(@RequestBody Stock stock) throws StockException {
		return stockService.createStock(stock);
	}

	@PutMapping("/updateStock/{id}")
	public List<Stock> updateStock(@PathVariable int id, @RequestBody Stock stock) throws StockException {
		return stockService.updateStock(id, stock);
	}

	@DeleteMapping(value = "/deleteStock/{id}")
	public ResponseEntity<String> deleteStock(@PathVariable int id) throws StockException {
		stockService.deleteStock(id);
		return new ResponseEntity<String>("Product with ID " + id + " deleted", HttpStatus.OK);
	}

	@RequestMapping("/viewAllStock")
	public List<Stock> viewAllStock() throws StockException {
		return stockService.viewAllStock();
	}

	@RequestMapping(value = "/findSingleStock/{id}")
	public Stock findSingleStock(@PathVariable int id) throws StockException {
		return stockService.findSingleStock(id);
	}

}
