package com.capg.exception;

public class PayWalletException extends Exception {
	public PayWalletException()
	{
		super();
	}
	public PayWalletException(String msg)
	{
		super(msg);
	}
	

}
