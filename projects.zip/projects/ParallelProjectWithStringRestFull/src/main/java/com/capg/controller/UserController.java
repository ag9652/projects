package com.capg.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capg.entities.PayWalletBean;
import com.capg.entities.TransactionBean;
import com.capg.exception.PayWalletException;
import com.capg.service.PayWalletService;


@RestController
@RequestMapping("/PayWallet")
public class UserController {
	@Autowired
	PayWalletService service;

	@GetMapping("/ShowOptions")
	public ResponseEntity<String> ShowOptions() {
		return new ResponseEntity<String>("Welcome to PayWallet Bank\n\n"+
				"1. Create Account 		: 	/CreateAccount\n"
				+ "2. Show Details 		: 	/ShowDetails/{accNo}\n"
				+ "3. Show Balance		: 	/ShowBalance/{accNo}\n"
				+ "4. Deposite Amount 	: 	/DepositAmount/{accNo}/{amt}\n"
				+ "5. Withdraw Amount 	: 	/WithdrawAmount/{accNo}/{amt}\n"
				+ "6. Fund Transafer 	: 	/FundTransfer/{accNo1}/{amt}/{accNo2}\n"
				+ "7. Mini Statement 	: 	/MiniStatement/{accNo}", HttpStatus.OK);
	}
	
	@PostMapping("/CreateAccount")
	public PayWalletBean createAccount(@RequestBody PayWalletBean bank) throws PayWalletException {
		return service.createAccount(bank);
	}

	@GetMapping("/ShowDetails/{accNo}")
	public PayWalletBean accountsDetails(@PathVariable Long accNo) throws PayWalletException {
		return service.accountsDetails(accNo);
	}

	@GetMapping("/ShowBalance/{accNo}")
	public ResponseEntity<String> showBalance(@PathVariable Long accNo) throws PayWalletException {
		Double bal = service.showBalance(accNo);
		return new ResponseEntity<String>("Your Current Balance : " + bal, HttpStatus.OK);
	}

	@PutMapping("/DepositAmount/{accNo}/{amt}")
	public ResponseEntity<String> deposit(@PathVariable Long accNo, @PathVariable Double amt) throws PayWalletException {
		Double bal = service.deposit(accNo, amt);
		return new ResponseEntity<String>("Your Updated Balance : " + bal, HttpStatus.OK);
	}

	@PutMapping("/WithdrawAmount/{accNo}/{amt}")
	public ResponseEntity<String> withdraw(@PathVariable Long accNo, @PathVariable Double amt) throws PayWalletException {
		Double bal = service.withdraw(accNo, amt);
		return new ResponseEntity<String>("Your Updated Balance : " + bal, HttpStatus.OK);
	}

	@PutMapping("/FundTransfer/{sender}/{amount}/{reciver}")
	public ResponseEntity<String> fundTransfer(@PathVariable Long sender, @PathVariable Double amount,
			@PathVariable Long reciver) throws PayWalletException {
		Double bal = service.fundTransfer(sender, amount, reciver);
		return new ResponseEntity<String>("Amount Transferred Successfully :-)\n-----------------------------------------"
				+ "\n\nTransaction Amount : "+amount
				+ "\nTransferred to : "+reciver+"\n\n-----------------------------------------\n"
				+ "Your Updated Balance : " +bal
				+ "\n-----------------------------------------", HttpStatus.OK);
	}

	@GetMapping("/MiniStatement/{accNo}")
	public List<TransactionBean> printTransaction(@PathVariable Long accNo) {
		return service.printTransaction(accNo);
	}

}
