package com.cg.service;

import java.sql.SQLException;

import com.cg.bean.BankBean;
import com.cg.bean.BankTransaction;
import com.cg.dao.BankDao;
import com.cg.dao.BankDaoI;
import com.cg.exceptions.*;

public class BankService implements BankServiceI {

	BankDaoI dao = (BankDaoI) new BankDao();
	BankBean bank = new BankBean();
	BankBean bank1 = new BankBean();

	boolean res;

	// to get the details if account exists or not and add account

	public boolean createAccount(String name, String add, long accNo, String phone, int pin, int bal)
			throws AccountAlreadyExistsException, ClassNotFoundException, SQLException {

		BankBean bean = new BankBean();
		boolean res = false;
		res = dao.checkAccount(accNo);

		if (res) {
			bean.setAccNo(accNo);
			bean.setAdd(add);
			bean.setBalance(bal);
			bean.setName(name);
			bean.setPhone(phone);
			bean.setPin(pin);
			bean.setTrans("Account Created with Balance  : " + bal + "\n");

			dao.InsertData(accNo, bean);

			res = true;
		}

		else

		{
			res = false;
			throw new AccountAlreadyExistsException();
		}
		return res;

	}

	// to show balance

	public int showBalance(long accNo) throws AccountNotFoundException, ClassNotFoundException, SQLException {

		try {
			res = dao.checkAccount(accNo);
		}

		catch (ClassNotFoundException | SQLException e) {
			System.out.println(e);
		}

		int balance = 0;

		if (res) {
			throw new AccountNotFoundException();
		} else {
			bank = dao.getAccountDetails(accNo);
			balance = bank.getBalance();
		}

		return balance;
	}

	// to deposit

	public int deposit(long accNo, int deposit_amount)
			throws AccountNotFoundException, ClassNotFoundException, SQLException {

		int balance = 0;
		try {
			res = dao.checkAccount(accNo);
		} catch (ClassNotFoundException | SQLException e) {
			System.out.println(e);
		}

		if (res) {
			throw new AccountNotFoundException();
		} else {
			bank = dao.getAccountDetails(accNo);
		}
		if (bank == null) {
			throw new AccountNotFoundException();
		} else {

			balance = bank.setBalance(bank.getBalance() + deposit_amount);
			String s = bank.getTrans() + "Amount deposited :" + deposit_amount + "\n";
			bank.setTrans(s);
		
			dao.updateData(bank);
		}

		return balance;
	}

	// to withdraw

	public int withdraw(long accNo, int withdraw_amount)
			throws AccountNotFoundException, LowBalanceException, ClassNotFoundException, SQLException {

		int balance = 0;
		try {
			res = dao.checkAccount(accNo);
		} catch (ClassNotFoundException | SQLException e) {
			System.out.println(e);
		}
		if (res) {
			throw new AccountNotFoundException();
		} else {
			bank = dao.getAccountDetails(accNo);
			if (bank == null) {
				throw new AccountNotFoundException();
			}
			if (bank.getBalance() > withdraw_amount) {
				balance = bank.setBalance(bank.getBalance() - withdraw_amount);
				String s = bank.getTrans() + "Amount withdrawn :" + withdraw_amount + "\n";
				bank.setTrans(s);
			} else {
				throw new LowBalanceException();
			}
			
			dao.updateData(bank);
		}

		return balance;
	}

	// to transfer fund

	public boolean transferfund(long accNo, long accNo1, int transfer_amount)
			throws AccountNotFoundException, LowBalanceException, ClassNotFoundException, SQLException {

		res = dao.checkAccount(accNo);
		if (res) {
			throw new AccountNotFoundException();
		} else {
			bank = dao.getAccountDetails(accNo);
			int balance = bank.getBalance();
			res = validateBalance(accNo, transfer_amount);
			if (res) {
				res = dao.checkAccount(accNo1);
				if (res) {
					throw new AccountNotFoundException();
				} else {
					bank1 = dao.getAccountDetails(accNo1);
					int balance1 = bank1.getBalance();
					bank.setBalance(balance - transfer_amount);
					bank1.setBalance(balance1 + transfer_amount);
					dao.updateData(bank);
					dao.updateData(bank1);
				}
			} else {
				throw new LowBalanceException();

			}
		}
		return true;
	}

	// to validateBalance

	public boolean validateBalance(long accNo, int amount)
			throws LowBalanceException, AccountNotFoundException, ClassNotFoundException, SQLException

	{

		res = dao.checkAccount(accNo);
		if (res) {
			throw new AccountNotFoundException();
		} else {
			bank = dao.getAccountDetails(accNo);
			int balance = bank.getBalance();
			if (balance < amount) {
				throw new LowBalanceException();
			} else {
				return true;
			}
		}
	}

	// to set transactions

	public String setTrans(long accNo) throws AccountNotFoundException {

		try {
			res = dao.checkAccount(accNo);
		} catch (ClassNotFoundException | SQLException e) {
			System.out.println(e);
		}
		String s;

		if (bank == null) {
			throw new AccountNotFoundException();
		} else {
			s = bank.getTrans();
		}
		return s;
	}

	@Override
	public void setTransactions(BankTransaction trans) throws ClassNotFoundException, SQLException {

		dao.setTransactions(trans);
	}

	@Override
	public BankTransaction getTransactions(long accNo) throws ClassNotFoundException, SQLException {
		BankTransaction trans = new BankTransaction();
		trans = dao.getTransactions(accNo);
		return trans;
	}
}
