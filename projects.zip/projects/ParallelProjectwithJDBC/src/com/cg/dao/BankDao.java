package com.cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cg.bean.BankBean;
import com.cg.bean.BankTransaction;

public class BankDao implements BankDaoI {

	Connection connection = null;
	PreparedStatement pstmt = null;
	ResultSet rs = null;
	BankBean bank = new BankBean();

	@Override
	public boolean checkAccount(long accNo) throws ClassNotFoundException, SQLException {

		boolean res = false;

		String query = "Select * from bank where accountno = ?";
		connection  = BankDB.getConnection();
		pstmt =connection .prepareStatement(query);
		pstmt.setLong(1, accNo);
		rs = pstmt.executeQuery();

		if (rs.next()) {
			res = false;
		} else {
			res = true;
		}
		return res;
	}

	@Override
	public void InsertData(long accNo, BankBean bean) throws ClassNotFoundException, SQLException {

		connection  = BankDB.getConnection();
		pstmt = connection .prepareStatement("Insert into bank values (?,?,?,?,?,?)");

		pstmt.setString(1, bean.getName());
		pstmt.setLong(2, bean.getAccNo());
		pstmt.setLong(3, bean.getPin());
		pstmt.setString(4, bean.getAdd());
		pstmt.setString(5, bean.getPhone());
		pstmt.setInt(6, bean.getBalance());

		int r =pstmt.executeUpdate();

		if (r == 0) {
			System.out.println("Not inserted");
		} else {
			System.out.println("Value inserted");
		}
	}

	@Override
	public void updateData(BankBean bean) throws ClassNotFoundException, SQLException {

		connection  = BankDB.getConnection();
		pstmt = connection .prepareStatement("Update bank set balance = ? where accountno = ?");
		pstmt.setInt(1, bean.getBalance());
		pstmt.setLong(2, bean.getAccNo());

		int r = pstmt.executeUpdate();

		if (r == 0) {
			System.out.println("Cannot update");
		} else {
			System.out.println("Updated");
		}
	}

	@Override
	public BankBean getAccountDetails(long accNo) throws ClassNotFoundException, SQLException {
		boolean res = false;

		String query = "Select * from bank where accountno = ?";
		connection  = BankDB.getConnection();
		pstmt = connection.prepareStatement(query);
		pstmt.setLong(1, accNo);
		rs =pstmt.executeQuery();

		if (rs.next()) {
			bank.setName(rs.getString(1));
			bank.setAccNo(rs.getLong(2));
			bank.setPin(rs.getInt(3));
			bank.setAdd(rs.getString(4));
			bank.setPhone(rs.getString(5));
			bank.setBalance(rs.getInt(6));
		} else {
			bank = null;
		}
		return bank;
	}

	@Override
	public void setTransactions(BankTransaction trans) throws ClassNotFoundException, SQLException {

		String query = "Insert into transactions values (?,?,?,?)";
		connection = BankDB.getConnection();
		pstmt= connection .prepareStatement(query);
		pstmt.setString(1, trans.getType());
		pstmt.setLong(2, trans.getAccNo());
		pstmt.setInt(3, trans.getAmount());
		pstmt.setInt(4, trans.getTransaction_id());

		int res = pstmt.executeUpdate();

		if (res == 0) {
			System.out.println("Cannot insert");
		} else {
			System.out.println("Updated ");
		}

	}

	@Override
	public BankTransaction getTransactions(long accNo) throws ClassNotFoundException, SQLException {

		BankTransaction trans = new BankTransaction();
		String query = "Select * from transactions where accountno = ?";
		connection = BankDB.getConnection();
		pstmt = connection .prepareStatement(query);
		pstmt.setLong(1, accNo);

		rs =pstmt.executeQuery();

		if (rs.next()) {
			trans.setType(rs.getString(1));
			trans.setAccNo(rs.getLong(2));
			trans.setAmount(rs.getInt(3));
			trans.setTransaction_id(rs.getInt(4));
		}
		return trans;
	}

}
